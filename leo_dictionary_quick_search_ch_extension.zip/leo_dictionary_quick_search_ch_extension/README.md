# leo_dictionary_quick_search_ch_extension

This is a lightweight Chrome extension that allows you to quickly search for selected words on the [LEO German-English Dictionary](https://dict.leo.org/german-english/) by simply selecting text on any webpage and pressing a specific key (default: **Shift**).

---

## ✅ Features

- Select any text on a webpage (e.g. click or highlight a word)
- Press the **Shift key** (can be customized)
- A new tab will automatically open with the selected word searched on the LEO dictionary
- Great for German learners and fast reading support

---

## 🔧 Installation (Developer Mode)

1. Download or clone this repository (or unzip the project folder)
2. Open Google Chrome and go to: [chrome://extensions/](chrome://extensions/)
3. Enable **Developer mode** (toggle switch in the top right)
4. Click **“Load unpacked”**, then select the folder `leo_dictionary_quick_search_ch_extension`
5. The extension will now be active in your browser

---

## 📁 Project Structure
leo_dictionary_quick_search_ch_extension/
├── manifest.json
└── content.js

---

## 🖱️ How to Use

1. Select a word on any webpage (via double-click or highlighting)
2. Press the **Shift key**
3. A new tab will open with that word searched on [dict.leo.org](https://dict.leo.org/german-english/)

---

## ⚙️ Customization

- You can change the trigger key in `content.js`. Look for this line:

  ```js
  if (event.key === "Shift")

Replace "Shift" with any key you prefer, such as "Alt", "Control", "Enter", etc.

To use another LEO language pair (e.g., German–French or German–Spanish), modify the URL in the same file:

```js
const leoURL = `https://dict.leo.org/german-english/${query}`;
```
## 🔐 Privacy
This extension does not send any data to external servers. It only reads the text you select on webpages and opens the LEO dictionary in a new tab. No personal data is collected or stored.

## 📄 License
MIT License — feel free to modify and share as you like.